-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2021 at 09:54 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `worker`
--

-- --------------------------------------------------------

--
-- Table structure for table `bid`
--

CREATE TABLE `bid` (
  `bidid` int(40) NOT NULL,
  `workerid` int(50) NOT NULL,
  `jobid` int(40) NOT NULL,
  `customerid` int(40) NOT NULL,
  `status` text NOT NULL,
  `category` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `fee` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerid` int(11) NOT NULL,
  `customername` text NOT NULL,
  `email` varchar(11) NOT NULL,
  `phoneno` int(11) NOT NULL,
  `address` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerid`, `customername`, `email`, `phoneno`, `address`) VALUES
(1, 'ami', 'ami@gmail.c', 983645, 'kallonpur'),
(2, 'tmi', 'tmi@gmail.c', 93635, 'dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `cv`
--

CREATE TABLE `cv` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phoneno` int(50) NOT NULL,
  `eduback` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `skill` text NOT NULL,
  `experience` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cv`
--

INSERT INTO `cv` (`id`, `name`, `email`, `address`, `phoneno`, `eduback`, `profession`, `gender`, `skill`, `experience`) VALUES
(4, 'tarin', 'tarin.aiub@gmail.com', 'Rangpur', 6434, 'hsc', 'electrician', 'female', 'lejfgi', 'yirrfgyuf'),
(5, 'mango', 'mango@gmail.com', 'Rangpur', 3445, 'psc', 'plumber', 'male', 'kertwiytriuwetyuiety', 'ehrgawuiergiutrg'),
(6, 'nirob', 'nirob@gmail.com', 'khulna', 2147483647, 'hsc', 'mechanic', 'male', 'ufuweteyefgsdyu', 'wekytuwetrtywer'),
(7, 'anisha1', 'anisha@gmail.com', 'dhakar', 565, 'hsc', 'tailor', 'female', 'aukfgiuaefgiudgakhsgjhkaf', 'ejfgkwjefgkuqef'),
(8, 'abc', 'abc@gmail.com', 'Khulna', 657894, 'hsc', 'mechanic', 'male', 'sehrgwuietrwr', 'uergyiwytrwetytr'),
(9, 'abe', 'abc@gmail.com', 'Rangpur', 546848, 'hsc', 'plumber', 'female', 'eyitflaey', 'tr');

-- --------------------------------------------------------

--
-- Table structure for table `joblist`
--

CREATE TABLE `joblist` (
  `id` int(50) NOT NULL,
  `customerid` int(50) NOT NULL,
  `status` text NOT NULL,
  `category` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `fee` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `joblist`
--

INSERT INTO `joblist` (`id`, `customerid`, `status`, `category`, `title`, `description`, `fee`) VALUES
(1, 1, 'posted', 'repair fan', 'electrician', 'fan is not working.', 200),
(2, 2, 'on process', 'repair fridge', 'electrician', 'fridge is not working.', 500);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(200) NOT NULL,
  `userid` int(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` text NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `userid`, `email`, `password`, `type`, `status`) VALUES
(1, 1, 'tarin.aiub@gmail.com', 'tarin', 'worker', 'deactive'),
(2, 3, 'anisha@gmail.com', 'anisha', 'worker', 'deactive'),
(3, 8, 'nirob@gmail.com', 'nirob', 'worker', 'deactive'),
(4, 9, 'mango@gmail.com', 'mango', 'worker', 'deactive'),
(5, 10, 'fahima@gmail.com', 'fahima', 'worker', 'deactive'),
(8, 11, 'abc@gmail.com', 'abc', 'worker', 'deactive'),
(9, 11, 'abc@gmail.com', 'abc', 'worker', 'deactive'),
(10, 14, 'mango@gmail.com', 'tamima', 'admin', 'Deactive'),
(11, 15, 'tarin@gmail.com', 'tarin', 'admin', 'Deactive'),
(12, 16, 'anisha@gmail.com', 'tarin', 'worker', 'deactive'),
(13, 15, 'tarin@gmail.com', 'tarin', 'worker', 'deactive'),
(14, 15, 'tarin@gmail.com', 'tarin', 'worker', 'deactive'),
(15, 2, 'tarin.aiub@gmail.com', 'Tarin', 'worker', 'deactive');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `messageid` int(11) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`messageid`, `message`) VALUES
(0, ''),
(0, ''),
(0, ''),
(0, '');

-- --------------------------------------------------------

--
-- Table structure for table `messaging`
--

CREATE TABLE `messaging` (
  `messageid` int(200) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messaging`
--

INSERT INTO `messaging` (`messageid`, `message`) VALUES
(9, 'please help'),
(10, 'tamima'),
(11, 'tarin'),
(12, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(110) NOT NULL,
  `name` varchar(110) NOT NULL,
  `email` varchar(110) NOT NULL,
  `password` varchar(110) NOT NULL,
  `phoneno` int(110) NOT NULL,
  `address` varchar(110) NOT NULL,
  `type` varchar(110) NOT NULL,
  `profession` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `email`, `password`, `phoneno`, `address`, `type`, `profession`) VALUES
(2, 'tarin', 'tarin.aiub@gmail.com', 'tarin', 785676, 'Rangpur', 'worker', 'chef'),
(8, 'nirob', 'nirob@gmail.com', 'nirob', 5634578, 'Khulna', 'admin', 'chef'),
(9, 'mango', 'mango@gmail.com', 'mango', 54576, 'Rangpur', 'worker', 'chef'),
(10, 'fahima', 'fahima@gmail.com', 'fahima', 757775, 'rah', 'worker', 'chef'),
(11, 'abc', 'abc@gmail.com', 'abc', 657454, 'Khulna', 'worker', 'tailor'),
(12, 'anisha', 'anisha@gmail.com', 'anisha', 5765, 'dhaka', 'worker', 'chef'),
(13, 'abc', 'abc@gmail.com', 'abc', 789766, 'Rangpur', 'worker', 'chef'),
(14, 'tarin', 'mango@gmail.com', 'tamima', 6434, 'Rangpur', 'worker', 'chef'),
(15, 'tarin', 'tarin@gmail.com', 'tarin', 6434, 'Rangpur', 'worker', 'chef'),
(16, 'anisha', 'anisha@gmail.com', 'tarin', 6434, 'Rangpur', 'worker', 'chef'),
(17, 'tarin', 'tarin@gmail.com', 'tarin', 6434, 'Rangpur', 'worker', 'chef'),
(18, 'tarin', 'tarin@gmail.com', 'tarin', 6434, 'Rangpur', 'worker', 'chef'),
(19, 'Tamima', 'tarin.aiub@gmail.com', 'Tarin', 6434, 'Rangpur', 'worker', 'chef');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bid`
--
ALTER TABLE `bid`
  ADD PRIMARY KEY (`bidid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `cv`
--
ALTER TABLE `cv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `joblist`
--
ALTER TABLE `joblist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messaging`
--
ALTER TABLE `messaging`
  ADD PRIMARY KEY (`messageid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bid`
--
ALTER TABLE `bid`
  MODIFY `bidid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cv`
--
ALTER TABLE `cv`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `joblist`
--
ALTER TABLE `joblist`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `messaging`
--
ALTER TABLE `messaging`
  MODIFY `messageid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
