var db = require('./db');

module.exports ={

	
getAll : function(callback){
		var sql = "select * from joblist ";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	
		insertbid: function(bid, callback){
		var sql = "insert into bid values(?,?,?,?,?,?,?,?,?)";
		//var sqlPrint="insert into bid values workerid="+user.userid+"status="+job.job_status+"category="+job.job_category+"title="+job.job_title+"description="+job.job_description+";";
		//console.log(sqlPrint);
		db.execute(sql, [ null,bid.userid,bid.jobid,bid.customerid,bid.status,bid.category,bid.title,bid.description,bid.fee], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});

	},
	getbyid : function(bid,callback)
	{
		var sql="select * from bid where userid=?";
		//var sqlPrint= "select * from cv where email="+cv.email+"";
		//console.log(sqlPrint);
		db.getResult(sql,[bid.userid],function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	delete: function(bid, callback){
		var sql = "delete from bid where bidid=?";
		db.execute(sql, [bid.bidid], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getById : function(customerid, callback){
		var sql = "select * from customer where customerid=?";
		db.getResult(sql, [customerid] , function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getallbid: function(callback){
		var sql = "select * from bid";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	
}